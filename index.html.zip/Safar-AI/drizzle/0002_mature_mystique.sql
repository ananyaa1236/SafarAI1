CREATE TABLE `agent_events` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`decision` text NOT NULL,
	`workflow` text NOT NULL,
	`reason` text NOT NULL,
	`mode` text NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `agent_approvals` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`request` text NOT NULL,
	`status` text NOT NULL,
	`created` integer NOT NULL,
	`expires` integer NOT NULL
);
