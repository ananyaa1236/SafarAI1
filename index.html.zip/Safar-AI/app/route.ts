import markup from '../public/index.html?raw';
export const dynamic = 'force-dynamic';
export function GET() { return new Response(markup, {headers:{'Content-Type':'text/html; charset=utf-8','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff','Cache-Control':'no-store'}}); }
