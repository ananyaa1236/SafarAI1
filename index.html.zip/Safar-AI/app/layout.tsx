import type { Metadata } from 'next';
export const metadata: Metadata = {title:'Safar-AI — Plan, Go, Remember',description:'One journey. Your itinerary, road routes, private travel diaries and social-ready memories.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
