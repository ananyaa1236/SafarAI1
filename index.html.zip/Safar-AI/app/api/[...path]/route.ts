import { env } from 'cloudflare:workers';
import { handleAgent } from '../../../server/agent.js';
import { handleApi } from '../../../server/diaries.js';
export const dynamic='force-dynamic';
export function GET(request:Request){return new URL(request.url).pathname.startsWith("/api/agent/")?handleAgent(request,env):handleApi(request,env)}
export function POST(request:Request){return new URL(request.url).pathname.startsWith("/api/agent/")?handleAgent(request,env):handleApi(request,env)}
export function PUT(request:Request){return new URL(request.url).pathname.startsWith("/api/agent/")?handleAgent(request,env):handleApi(request,env)}
export function DELETE(request:Request){return new URL(request.url).pathname.startsWith("/api/agent/")?handleAgent(request,env):handleApi(request,env)}
