# Safar-AI — Plan, Go, Remember

The existing travel website is preserved inside `public/`. A connected journey workspace ties its itinerary and budget to road routes, stops, photo collections, journals and carousel exports. Every generated trip creates an album. Every itinerary activity has a Capture Memory action. Album records include the original itinerary, so reopening an album can reopen its trip.

## Local use
- Frontend only: open `public/` with VS Code Live Server. Albums/photos/creations persist in IndexedDB on this browser. This mode is explicitly labelled and has no account security or cross-device sync. Do not open index.html with file://.
- Full app: Node 22.13+, install from `pnpm-lock.yaml`, then `npm run dev`. Hosting uses the supplied Vinext/Cloudflare Sites integration. The managed preview is started through Sites preview. Hosted identity is dispatch-owned ChatGPT sign-in; no passwords are collected.
- Build: `node /root/.codex/plugins/cache/openai-curated-remote/sites/1.1.3/scripts/build-site.mjs` in this environment; standalone `npm run build` is also supported.

## Database & photo storage
`.openai/hosting.json` declares logical D1 `DB` and R2 `BUCKET`. Sites provisions the hosted resources. User IDs come from platform-injected authenticated identity headers. Every album/photo/edition mutation is scoped to that user. Images are served only to the owner or via a valid, unexpired share token for an edition that references that photo.

Schema is in `db/schema.ts`; migration is in `drizzle/0000_stale_nemesis.sql`. The initial local migration has been applied to the preview. For a fresh checkout, build, then apply this migration to local D1:
```
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_stale_nemesis.sql
```
Do not replay applied migrations. Sites applies pending hosted migrations on deployment. Tables: albums, photos, editions, shares, ai_runs. Source migrations contain schema only, no user/demo data.

Uploads are real multipart requests to R2, with metadata in D1. JPEG/PNG/WebP signatures, dimensions, day selection, account size quotas and owner access are validated. The browser normalizes images to a maximum 1600 px and strips EXIF/GPS before storage. Original EXIF dates can suggest an itinerary day; optional local GPS matching works only against attractions with known coordinates within 500 m. Missing metadata falls back to manual selection, not invented locations. HEIC needs conversion. Phone capture is exposed via file-input capture where the browser supports it. Max 12 files per batch; source max 20 MB, stored max 4 MB/image, cloud quota 500 images / 300 MB/account. Removal is a soft delete and does not erase copies previously exported by a visitor.

## Journal & social studio
Actual uploaded photos appear in canvas-rendered pages/slides. Notes-based composition uses only photographed collections and user notes. Editable title/subtitle/story, photo selection, order, font, background and layouts are included. Themes: aesthetic, cinematic, vintage, minimalist, magazine, polaroid and photo dump. Carousel count: 3–10; a small album can reuse a photo across slides. Journals group photos by itinerary day and attraction. Portrait 1080×1350, square 1080×1080, Pinterest 1000×1500 and story 1080×1920 exports are supported. PDF pages embed raster JPEGs; PDF text is not selectable. ZIP contains rendered PNG slides plus a caption file. Exports respect the on-screen preview; long edited text can be visually truncated, so review and shorten text before export.

Creations are saved as editable documents in D1 (or IndexedDB in device-only mode). Revocable server-side share tokens are hashed in storage, expire after seven days and expose only the saved creation's referenced photographs. The site's private audience is preserved: a journal URL does NOT grant public access to the site. Downloads/native sharing work without making albums public. Direct Instagram/Pinterest publishing is not connected; exports and manual-post links are available.

## Gemini setup (optional, not configured)
Set server runtime secrets `GEMINI_API_KEY` and optional `GEMINI_MODEL` through Sites environment settings, never in frontend JS/HTML or the hosting manifest. Default model is `gemini-3.8-flash`; choose a currently accessible image-capable model for your account. For local development use an ignored environment file supported by the runtime. `.env.example` lists names only.

`POST /api/albums/:id/story` requires authenticated ownership, explicit consent and limits requests to ten/hour/user. It sends source notes and, only with the separate images checkbox, up to six eligible images. The prompt forbids invented experiences/locations. Returned paragraph place names must match source records. Generated language is still a draft to review. If credentials/access/network are missing, no AI success is claimed; notes-based composition and photo exports remain available. The live Gemini path cannot be end-to-end verified without a valid key.

## Route integration retained
Photon place choices, OSRM road distance/time/alternatives, optional geolocation, interval rest-point interpolation, Overpass real-hotel lookup with a limited Photon fallback, actual detour calls, stops and nearby categories are retained. Planner fields carry into route search, and selected routes attach to the same current trip. New map attractions carry coordinates into itinerary memories. Route/places requests need connectivity and public services may throttle or fail. There is no live traffic, authorized hotel quote inventory or verified official hotel classification. Prices remain unavailable rather than fabricated.

## Checks
- `node tests/diaries.test.mjs` checks SQL persistence, owner isolation, private photo access, uploaded signatures, source-photo edition ownership, share access/revocation, deleted-photo access and no-key fallback against a real in-memory SQLite database and an R2 interface stub.
- `node scripts/check-road-math.cjs` checks road geometry and interval boundaries (the script now reads public/roadtrip.js).
- Browser QA: real image upload, destination association, journal preview, persisted album reopening, and exports are checked separately. No credentials, private images or user records are committed to source.
