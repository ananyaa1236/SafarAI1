const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const source=fs.readFileSync('public/roadtrip.js','utf8');
const math=source.slice(source.indexOf('function rad('),source.indexOf('function icon('));
const context=vm.createContext({Math,routes:[],activeRoute:0,cumulative:[]});vm.runInContext(math,context);
// Right-angle road: a midpoint must follow the road geometry, not the chord.
vm.runInContext('routes=[{geometry:{coordinates:[[0,0],[1,0],[1,1]]}}];cumulative=lineLengths(routes[0].geometry.coordinates)',context);
const middle=vm.runInContext('pointAt(cumulative[1])',context);assert.ok(Math.abs(middle[0]-1)<1e-9);assert.ok(Math.abs(middle[1])<1e-9);
const start=vm.runInContext('pointAt(-1)',context),end=vm.runInContext('pointAt(1e9)',context);assert.equal(start[0],0);assert.equal(end[1],1);
const nearest=vm.runInContext('nearestOnLine([1.01,0.5])',context);assert.ok(nearest.gap>1100&&nearest.gap<1120);assert.ok(nearest.along>160000&&nearest.along<170000);
// Exact 300 km route must yield 50,100,150,200,250,300 without duplicating endpoint.
const intervalFunction=source.slice(source.indexOf('function computeRestPoints('),source.indexOf('function renderRestPicker('));
Object.assign(context,{km:m=>m/1000+' km',intervalMeters:()=>50000,restLayer:{clearLayers(){}},renderRestPicker(){},updateNextStop(){},L:{marker(){return{addTo(){return this},bindTooltip(){return this},on(){return this}}}},icon(){},restPoints:[],map:{},restLayer:{clearLayers(){}}});
vm.runInContext('routes[0].distance=300000;'+intervalFunction+';computeRestPoints()',context);assert.equal(vm.runInContext('restPoints.length',context),6);assert.equal(vm.runInContext('restPoints[5].distance',context),300000);
vm.runInContext('routes[0].distance=22500;computeRestPoints()',context);assert.equal(vm.runInContext('restPoints.length',context),1);assert.equal(vm.runInContext('restPoints[0].distance',context),22500);
console.log('Road geometry, nearest-route projection, interval boundary and endpoint checks passed.');
