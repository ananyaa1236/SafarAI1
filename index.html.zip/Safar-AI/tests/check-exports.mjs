import fs from 'node:fs';import vm from 'node:vm';
const fixture=process.argv[2];if(!fixture)throw Error('Usage: node tests/check-exports.mjs /absolute/path/to/sample.jpg');const s=fs.readFileSync('public/diaries.js','utf8'),jpeg=fs.readFileSync(fixture);
const context=vm.createContext({Blob,TextEncoder,Uint8Array,DataView,Math,Array,studio:{title:'QA photo journal',slides:[{photoIds:['photo1']},{photoIds:['photo1']},{photoIds:['photo1']}]},D:()=>({textContent:''}),renderSlide:async()=>({width:1080,height:1350}),canvasBlob:async()=>new Blob([jpeg],{type:'image/jpeg'})});
vm.runInContext(s.slice(s.indexOf('const utf8='),s.indexOf('async function exportZIP(')),context);
vm.runInContext(s.slice(s.indexOf('async function pdfBlob('),s.indexOf('async function exportPDF(')),context);
const pdf=await vm.runInContext('pdfBlob()',context);fs.writeFileSync((process.argv[3]||'/tmp')+'/safar-format-test.pdf',Buffer.from(await pdf.arrayBuffer()));
context.files=[{name:'photo.jpg',bytes:new Uint8Array(jpeg)},{name:'caption.txt',bytes:new TextEncoder().encode('QA sample')}];const zip=vm.runInContext('zipFiles(files)',context);fs.writeFileSync((process.argv[3]||'/tmp')+'/safar-format-test.zip',Buffer.from(await zip.arrayBuffer()));console.log('PDF and ZIP binary format fixtures written.');
